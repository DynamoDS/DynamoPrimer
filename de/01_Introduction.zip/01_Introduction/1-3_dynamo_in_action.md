

## Dynamo in Aktion

Ob Sie die visuelle Programmierung für Arbeitsabläufe in Projekten nutzen oder eigene Werkzeuge entwickeln: Dynamo ist unverzichtbarer Bestandteil in einer Vielzahl möglicher Anwendungen.

[Folgen Sie dem Dynamo in Action-Board auf Pinterest.](http://www.pinterest.com/modelabnyc/dynamo-in-action/)

