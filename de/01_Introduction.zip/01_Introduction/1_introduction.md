

# Einführung

Dynamo wurde ursprünglich als Zusatzmodul für Building Information Modeling in Revit entwickelt, ist seitdem gewachsen und kann auf vielfältige Weise genutzt werden. In erster Linie ist Dynamo eine Plattform, die es Designern ermöglicht, mit visueller Programmierung zu experimentieren, Probleme zu lösen und eigene Werkzeuge zu entwickeln. Zu Beginn dieser Einführung finden Sie hier eine Beschreibung des Kontexts für Dynamo: Was ist dieses Programm und wie können Sie es verwenden?

![Dynamo-Ökosystem](images/1/1-cover.jpg)

